// ==UserScript==
// @id             iitc-plugin-highlight-portals-by-ap-relative@vita10gy
// @name           IITC plugin: highlight portals by ap relative
// @category  Deleted
// @version        0.1.1.20161003.2636
// @namespace      https://github.com/jonatkins/ingress-intel-total-conversion
// @updateURL      https://static.iitc.me/build/release/plugins/portal-highlighter-portal-ap-relative.meta.js
// @downloadURL    https://static.iitc.me/build/release/plugins/portal-highlighter-portal-ap-relative.user.js
// @description    This plugin is no longer available, as Niantic optimisations have removed the data it needed.
// @include        https://*.ingress.com/intel*
// @include        http://*.ingress.com/intel*
// @match          https://*.ingress.com/intel*
// @match          http://*.ingress.com/intel*
// @include        https://*.ingress.com/mission/*
// @include        http://*.ingress.com/mission/*
// @match          https://*.ingress.com/mission/*
// @match          http://*.ingress.com/mission/*
// @grant          none
// ==/UserScript==
