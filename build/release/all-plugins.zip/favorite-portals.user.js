// ==UserScript==
// @id             iitc-plugin-favorite-portals@soulBit
// @name           IITC plugin: Favorite Portals
// @category  Deleted
// @version        0.2.0.20150917.154202
// @description    Plugin replaced by the "Bookmarks for maps and portals" plugin
// @namespace      https://github.com/jonatkins/ingress-intel-total-conversion
// @updateURL      https://secure.jonatkins.com/iitc/release/plugins/favorite-portals.meta.js
// @downloadURL    https://secure.jonatkins.com/iitc/release/plugins/favorite-portals.user.js
// @include        https://www.ingress.com/intel*
// @include        http://www.ingress.com/intel*
// @match          https://www.ingress.com/intel*
// @match          http://www.ingress.com/intel*
// @include        https://www.ingress.com/mission/*
// @include        http://www.ingress.com/mission/*
// @match          https://www.ingress.com/mission/*
// @match          http://www.ingress.com/mission/*
// @grant          none
// ==/UserScript==
