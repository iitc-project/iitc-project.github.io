// ==UserScript==
// @id             iitc-plugin-highlight-portals-by-ap@vita10gy
// @name           IITC plugin: highlight portals by ap
// @category  Deleted
// @version        0.1.1.20151111.74206
// @namespace      https://github.com/jonatkins/ingress-intel-total-conversion
// @updateURL      https://secure.jonatkins.com/iitc/test/plugins/portal-highlighter-portal-ap.meta.js
// @downloadURL    https://secure.jonatkins.com/iitc/test/plugins/portal-highlighter-portal-ap.user.js
// @description    This plugin is no longer available, as Niantic optimisations have removed the data it needed.
// @include        https://www.ingress.com/intel*
// @include        http://www.ingress.com/intel*
// @match          https://www.ingress.com/intel*
// @match          http://www.ingress.com/intel*
// @include        https://www.ingress.com/mission/*
// @include        http://www.ingress.com/mission/*
// @match          https://www.ingress.com/mission/*
// @match          http://www.ingress.com/mission/*
// @grant          none
// ==/UserScript==
