// ==UserScript==
// @id             iitc-plugin-cloudmade-maps
// @name           IITC plugin: CloudMade.com maps
// @category       Deleted
// @version        0.0.0
// @namespace      https://github.com/jonatkins/ingress-intel-total-conversion
// @description    Cloudmade no longer offer free accounts for map tiles.
// @include        https://www.ingress.com/intel*
// @include        http://www.ingress.com/intel*
// @match          https://www.ingress.com/intel*
// @match          http://www.ingress.com/intel*
// @include        https://www.ingress.com/mission/*
// @include        http://www.ingress.com/mission/*
// @match          https://www.ingress.com/mission/*
// @match          http://www.ingress.com/mission/*
// ==/UserScript==

