// ==UserScript==
// @id             iitc-plugin-players-portal-pictures
// @name           IITC plugin: Player's Portal Pictures
// @version        0.1.0.20161003.4825
// @category       Deleted
// @namespace      https://github.com/jonatkins/ingress-intel-total-conversion
// @updateURL      https://static.iitc.me/build/test/plugins/players-portal-pictures.meta.js
// @downloadURL    https://static.iitc.me/build/test/plugins/players-portal-pictures.user.js
// @description    [iitc-test-2016-10-03-004825] Niantic removed the data this plugin needed. It is no longer possible to search for photo submitter.
// @include        https://*.ingress.com/intel*
// @include        http://*.ingress.com/intel*
// @match          https://*.ingress.com/intel*
// @match          http://*.ingress.com/intel*
// @include        https://*.ingress.com/mission/*
// @include        http://*.ingress.com/mission/*
// @match          https://*.ingress.com/mission/*
// @match          http://*.ingress.com/mission/*
// @grant          none
// ==/UserScript==

