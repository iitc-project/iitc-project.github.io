// ==UserScript==
// @id             iitc-plugin-show-more-portals@jonatkins
// @name           IITC plugin: Show more portals
// @category       Deleted
// @version        0.2.1.20151111.74206
// @namespace      https://github.com/jonatkins/ingress-intel-total-conversion
// @updateURL      https://secure.jonatkins.com/iitc/test/plugins/show-more-portals.meta.js
// @downloadURL    https://secure.jonatkins.com/iitc/test/plugins/show-more-portals.user.js
// @description    [jonatkins-test-2015-11-11-074206] Standard intel has changed to show all portals from zoom level 15, which is what this plugin used to force.
// @include        https://www.ingress.com/intel*
// @include        http://www.ingress.com/intel*
// @match          https://www.ingress.com/intel*
// @match          http://www.ingress.com/intel*
// @include        https://www.ingress.com/mission/*
// @include        http://www.ingress.com/mission/*
// @match          https://www.ingress.com/mission/*
// @match          http://www.ingress.com/mission/*
// @grant          none
// ==/UserScript==

