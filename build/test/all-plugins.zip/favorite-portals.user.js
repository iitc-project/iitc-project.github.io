// ==UserScript==
// @id             iitc-plugin-favorite-portals@soulBit
// @name           IITC plugin: Favorite Portals
// @category  Deleted
// @version        0.2.0.20161003.4825
// @description    Plugin replaced by the "Bookmarks for maps and portals" plugin
// @namespace      https://github.com/jonatkins/ingress-intel-total-conversion
// @updateURL      https://static.iitc.me/build/test/plugins/favorite-portals.meta.js
// @downloadURL    https://static.iitc.me/build/test/plugins/favorite-portals.user.js
// @include        https://*.ingress.com/intel*
// @include        http://*.ingress.com/intel*
// @match          https://*.ingress.com/intel*
// @match          http://*.ingress.com/intel*
// @include        https://*.ingress.com/mission/*
// @include        http://*.ingress.com/mission/*
// @match          https://*.ingress.com/mission/*
// @match          http://*.ingress.com/mission/*
// @grant          none
// ==/UserScript==
